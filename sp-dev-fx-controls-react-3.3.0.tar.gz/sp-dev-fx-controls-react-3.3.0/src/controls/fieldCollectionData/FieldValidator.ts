export interface FieldValidator {
  [property: string]: boolean;
}
