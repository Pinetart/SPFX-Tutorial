export enum EMembershipType {
  "Standard" = "standard",
  "Private" = "private"
}
