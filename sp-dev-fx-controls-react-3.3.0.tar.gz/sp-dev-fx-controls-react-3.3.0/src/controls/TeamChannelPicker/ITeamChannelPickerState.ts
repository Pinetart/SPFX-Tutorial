import { ITag } from "office-ui-fabric-react/lib/Pickers";

export interface ITeamChannelPickerState {
  selectedTeamsChannels:ITag[];
}
