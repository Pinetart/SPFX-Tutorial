export interface IIFramePanelState {
}
