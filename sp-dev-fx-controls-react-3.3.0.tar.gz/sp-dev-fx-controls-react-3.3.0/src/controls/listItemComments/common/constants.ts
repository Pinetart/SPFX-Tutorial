export const PHOTO_URL = "/_layouts/15/userphoto.aspx?size=M&accountname=";
export const TILE_HEIGHT: number = 70;
