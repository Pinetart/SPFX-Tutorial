export interface INewFolderState {
  folderName: string;
  showInput: boolean;
  loading: boolean;
  errorMessage?: string;
}
