import * as React from 'react';

export type DivAttributes = React.HTMLAttributes<HTMLDivElement>;
