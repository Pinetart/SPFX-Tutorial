export interface IIFramePanelContentState {
  isContentVisible?: boolean;
}
