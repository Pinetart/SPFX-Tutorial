
export interface IUploadAttachmentState {
      hideDialog: boolean;
      dialogMessage: string;
      isLoading: boolean;

}
