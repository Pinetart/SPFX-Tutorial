export interface ICollectionNumberFieldState {
  value: number;
  errorMessage: string;
}
