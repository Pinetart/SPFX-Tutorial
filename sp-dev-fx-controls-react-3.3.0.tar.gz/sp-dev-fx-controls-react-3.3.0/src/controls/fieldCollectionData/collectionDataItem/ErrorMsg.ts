export interface ErrorMsg {
  field: string;
  message?: string;
  isRequired?: boolean;
}
