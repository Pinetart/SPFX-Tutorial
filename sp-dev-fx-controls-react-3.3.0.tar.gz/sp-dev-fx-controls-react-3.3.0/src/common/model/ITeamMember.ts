export interface ITeamMenber  {
  '@odata.type': string;
  id: string;
  roles: any[];
  displayName: string;
  userId: string;
  email: string;
}
