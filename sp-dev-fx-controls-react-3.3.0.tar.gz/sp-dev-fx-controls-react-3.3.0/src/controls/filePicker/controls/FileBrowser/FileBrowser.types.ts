export type ViewType = 'list' | 'compact' | 'tiles';
