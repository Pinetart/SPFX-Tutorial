export interface IErrorInfo {
   error:Error;
   showError:boolean;
}
