export enum ECommentAction {
  "ADD" = "ADD",
  "DELETE" = "DELETE"
}
