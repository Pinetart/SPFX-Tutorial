export const  TEAMS_SVG_LOGO  =   "https://static2.sharepointonline.com/files/fabric/assets/brand-icons/product/svg/teams_48x1.svg";
