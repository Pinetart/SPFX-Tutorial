export interface IFilePickerState {
  showFullNav?: boolean; // reserved for future use
  panelOpen?: boolean;
  selectedTab?: string;

  organisationAssetsEnabled?: boolean;
}
