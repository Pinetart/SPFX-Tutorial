export interface IDynamicFieldState {
  /**
  * The options available to the listPicker
  */
  changedValue: any;
}
