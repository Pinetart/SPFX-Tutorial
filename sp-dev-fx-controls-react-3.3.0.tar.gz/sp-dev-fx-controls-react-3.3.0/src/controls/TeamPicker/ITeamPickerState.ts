import { ITag } from "office-ui-fabric-react/lib/Pickers";

export interface ITeamPickerState {
  savedSelectedTeams:ITag[];
}
