/**
 * Types of controls available to render time part
 */
export enum TimeDisplayControlType {
  /**
   * masked edit
   */
  Text,
  /**
   * dropdown
   */
  Dropdown
}
