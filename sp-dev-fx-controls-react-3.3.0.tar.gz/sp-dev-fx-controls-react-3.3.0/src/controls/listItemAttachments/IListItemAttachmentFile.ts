export interface IListItemAttachmentFile{
  FileName : string;
  ServerRelativeUrl: string;
}
