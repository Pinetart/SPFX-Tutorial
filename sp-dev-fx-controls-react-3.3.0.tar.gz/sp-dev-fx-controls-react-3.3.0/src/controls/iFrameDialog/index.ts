export * from './IFrameDialogContent.module.scss';
export * from './IFrameDialogContent';
export * from './IFrameDialog';