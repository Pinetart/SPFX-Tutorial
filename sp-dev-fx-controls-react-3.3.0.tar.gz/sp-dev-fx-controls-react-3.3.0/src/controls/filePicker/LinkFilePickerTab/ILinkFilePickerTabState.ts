import { IFilePickerResult } from "../FilePicker.types";

export interface ILinkFilePickerTabState {
  filePickerResult?: IFilePickerResult;
  isValid: boolean;
}
