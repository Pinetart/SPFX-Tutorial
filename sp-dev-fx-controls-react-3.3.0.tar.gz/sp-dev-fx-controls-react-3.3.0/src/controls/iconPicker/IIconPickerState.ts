export interface IIconPickerState {
    items: string[];
    currentIcon?: string;
    isPanelOpen: boolean;
}
