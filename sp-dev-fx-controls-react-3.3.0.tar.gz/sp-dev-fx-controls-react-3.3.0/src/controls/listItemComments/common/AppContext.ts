import * as React from "react";

import { IAppContext } from ".";

export const AppContext = React.createContext<IAppContext>(undefined);
